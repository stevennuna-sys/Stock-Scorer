import StockScorerV32 from "./components/StockScorerV32";

export default function Page() {
  return <StockScorerV32 />;
}
