# Stock Scorer

## Run locally
1. Install dependencies
   npm install

2. Start dev server
   npm run dev
